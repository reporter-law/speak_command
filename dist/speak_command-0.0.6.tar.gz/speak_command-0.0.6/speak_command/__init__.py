"""程序说明"""
# -*-  coding: utf-8 -*-
# Author: cao wang
# Datetime : 2020
# software: PyCharm
__version__ = "1.0.0"
from .speak_command import command_speak