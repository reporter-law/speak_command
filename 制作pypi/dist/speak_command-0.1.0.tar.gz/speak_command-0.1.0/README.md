# speak_command

实现语音输入输出，综合组合了语音转文本、文本转语音、录音、自然语言处理等技术，实现语音控制

下载方式
  
    pip install speak_command
  
使用方式：
    import speak_command as sc
    text = sc.command_speak()
    print(text)
注意问题：需要挂上vpn，因为使用了谷歌语音识别。

vpn用的是蓝灯破解自动500M流量，
  链接：https://pan.baidu.com/s/12i85LTKzZVAZ5MAJ6lsQrQ，提取码：0gxs


  
